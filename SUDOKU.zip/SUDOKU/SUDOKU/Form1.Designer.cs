﻿namespace SUDOKU
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.buttonsudoku55 = new SUDOKU.buttonsudoku();
            this.buttonsudoku56 = new SUDOKU.buttonsudoku();
            this.buttonsudoku57 = new SUDOKU.buttonsudoku();
            this.buttonsudoku58 = new SUDOKU.buttonsudoku();
            this.buttonsudoku59 = new SUDOKU.buttonsudoku();
            this.buttonsudoku60 = new SUDOKU.buttonsudoku();
            this.buttonsudoku61 = new SUDOKU.buttonsudoku();
            this.buttonsudoku62 = new SUDOKU.buttonsudoku();
            this.buttonsudoku63 = new SUDOKU.buttonsudoku();
            this.buttonsudoku64 = new SUDOKU.buttonsudoku();
            this.buttonsudoku65 = new SUDOKU.buttonsudoku();
            this.buttonsudoku66 = new SUDOKU.buttonsudoku();
            this.buttonsudoku67 = new SUDOKU.buttonsudoku();
            this.buttonsudoku68 = new SUDOKU.buttonsudoku();
            this.buttonsudoku69 = new SUDOKU.buttonsudoku();
            this.buttonsudoku70 = new SUDOKU.buttonsudoku();
            this.buttonsudoku71 = new SUDOKU.buttonsudoku();
            this.buttonsudoku72 = new SUDOKU.buttonsudoku();
            this.buttonsudoku73 = new SUDOKU.buttonsudoku();
            this.buttonsudoku74 = new SUDOKU.buttonsudoku();
            this.buttonsudoku75 = new SUDOKU.buttonsudoku();
            this.buttonsudoku76 = new SUDOKU.buttonsudoku();
            this.buttonsudoku77 = new SUDOKU.buttonsudoku();
            this.buttonsudoku78 = new SUDOKU.buttonsudoku();
            this.buttonsudoku79 = new SUDOKU.buttonsudoku();
            this.buttonsudoku80 = new SUDOKU.buttonsudoku();
            this.buttonsudoku81 = new SUDOKU.buttonsudoku();
            this.buttonsudoku28 = new SUDOKU.buttonsudoku();
            this.buttonsudoku29 = new SUDOKU.buttonsudoku();
            this.buttonsudoku30 = new SUDOKU.buttonsudoku();
            this.buttonsudoku31 = new SUDOKU.buttonsudoku();
            this.buttonsudoku32 = new SUDOKU.buttonsudoku();
            this.buttonsudoku33 = new SUDOKU.buttonsudoku();
            this.buttonsudoku34 = new SUDOKU.buttonsudoku();
            this.buttonsudoku35 = new SUDOKU.buttonsudoku();
            this.buttonsudoku36 = new SUDOKU.buttonsudoku();
            this.buttonsudoku37 = new SUDOKU.buttonsudoku();
            this.buttonsudoku38 = new SUDOKU.buttonsudoku();
            this.buttonsudoku39 = new SUDOKU.buttonsudoku();
            this.buttonsudoku40 = new SUDOKU.buttonsudoku();
            this.buttonsudoku41 = new SUDOKU.buttonsudoku();
            this.buttonsudoku42 = new SUDOKU.buttonsudoku();
            this.buttonsudoku43 = new SUDOKU.buttonsudoku();
            this.buttonsudoku44 = new SUDOKU.buttonsudoku();
            this.buttonsudoku45 = new SUDOKU.buttonsudoku();
            this.buttonsudoku46 = new SUDOKU.buttonsudoku();
            this.buttonsudoku47 = new SUDOKU.buttonsudoku();
            this.buttonsudoku48 = new SUDOKU.buttonsudoku();
            this.buttonsudoku49 = new SUDOKU.buttonsudoku();
            this.buttonsudoku50 = new SUDOKU.buttonsudoku();
            this.buttonsudoku51 = new SUDOKU.buttonsudoku();
            this.buttonsudoku52 = new SUDOKU.buttonsudoku();
            this.buttonsudoku53 = new SUDOKU.buttonsudoku();
            this.buttonsudoku54 = new SUDOKU.buttonsudoku();
            this.buttonsudoku19 = new SUDOKU.buttonsudoku();
            this.buttonsudoku20 = new SUDOKU.buttonsudoku();
            this.buttonsudoku21 = new SUDOKU.buttonsudoku();
            this.buttonsudoku22 = new SUDOKU.buttonsudoku();
            this.buttonsudoku23 = new SUDOKU.buttonsudoku();
            this.buttonsudoku24 = new SUDOKU.buttonsudoku();
            this.buttonsudoku25 = new SUDOKU.buttonsudoku();
            this.buttonsudoku26 = new SUDOKU.buttonsudoku();
            this.buttonsudoku27 = new SUDOKU.buttonsudoku();
            this.buttonsudoku10 = new SUDOKU.buttonsudoku();
            this.buttonsudoku11 = new SUDOKU.buttonsudoku();
            this.buttonsudoku12 = new SUDOKU.buttonsudoku();
            this.buttonsudoku13 = new SUDOKU.buttonsudoku();
            this.buttonsudoku14 = new SUDOKU.buttonsudoku();
            this.buttonsudoku15 = new SUDOKU.buttonsudoku();
            this.buttonsudoku16 = new SUDOKU.buttonsudoku();
            this.buttonsudoku17 = new SUDOKU.buttonsudoku();
            this.buttonsudoku18 = new SUDOKU.buttonsudoku();
            this.buttonsudoku7 = new SUDOKU.buttonsudoku();
            this.buttonsudoku8 = new SUDOKU.buttonsudoku();
            this.buttonsudoku9 = new SUDOKU.buttonsudoku();
            this.buttonsudoku4 = new SUDOKU.buttonsudoku();
            this.buttonsudoku5 = new SUDOKU.buttonsudoku();
            this.buttonsudoku6 = new SUDOKU.buttonsudoku();
            this.buttonsudoku3 = new SUDOKU.buttonsudoku();
            this.buttonsudoku2 = new SUDOKU.buttonsudoku();
            this.buttonsudoku1 = new SUDOKU.buttonsudoku();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(482, 60);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(21, 20);
            this.button82.TabIndex = 81;
            this.button82.Text = "1";
            this.button82.UseVisualStyleBackColor = true;
            this.button82.Click += new System.EventHandler(this.button82_Click);
            // 
            // button83
            // 
            this.button83.Location = new System.Drawing.Point(509, 60);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(21, 20);
            this.button83.TabIndex = 82;
            this.button83.Text = "2";
            this.button83.UseVisualStyleBackColor = true;
            this.button83.Click += new System.EventHandler(this.button83_Click);
            // 
            // button84
            // 
            this.button84.Location = new System.Drawing.Point(536, 60);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(21, 20);
            this.button84.TabIndex = 83;
            this.button84.Text = "3";
            this.button84.UseVisualStyleBackColor = true;
            this.button84.Click += new System.EventHandler(this.button84_Click);
            // 
            // button85
            // 
            this.button85.Location = new System.Drawing.Point(536, 86);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(21, 20);
            this.button85.TabIndex = 86;
            this.button85.Text = "6";
            this.button85.UseVisualStyleBackColor = true;
            this.button85.Click += new System.EventHandler(this.button85_Click);
            // 
            // button86
            // 
            this.button86.Location = new System.Drawing.Point(509, 86);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(21, 20);
            this.button86.TabIndex = 85;
            this.button86.Text = "5";
            this.button86.UseVisualStyleBackColor = true;
            this.button86.Click += new System.EventHandler(this.button86_Click);
            // 
            // button87
            // 
            this.button87.Location = new System.Drawing.Point(482, 86);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(21, 20);
            this.button87.TabIndex = 84;
            this.button87.Text = "4";
            this.button87.UseVisualStyleBackColor = true;
            this.button87.Click += new System.EventHandler(this.button87_Click);
            // 
            // button88
            // 
            this.button88.Location = new System.Drawing.Point(536, 112);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(21, 20);
            this.button88.TabIndex = 89;
            this.button88.Text = "9";
            this.button88.UseVisualStyleBackColor = true;
            this.button88.Click += new System.EventHandler(this.button88_Click);
            // 
            // button89
            // 
            this.button89.Location = new System.Drawing.Point(509, 112);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(21, 20);
            this.button89.TabIndex = 88;
            this.button89.Text = "8";
            this.button89.UseVisualStyleBackColor = true;
            this.button89.Click += new System.EventHandler(this.button89_Click);
            // 
            // button90
            // 
            this.button90.Location = new System.Drawing.Point(482, 112);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(21, 20);
            this.button90.TabIndex = 87;
            this.button90.Text = "7";
            this.button90.UseVisualStyleBackColor = true;
            this.button90.Click += new System.EventHandler(this.button90_Click);
            // 
            // button91
            // 
            this.button91.Location = new System.Drawing.Point(13, 28);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(60, 77);
            this.button91.TabIndex = 90;
            this.button91.UseVisualStyleBackColor = true;
            // 
            // buttonsudoku55
            // 
            this.buttonsudoku55.Location = new System.Drawing.Point(435, 427);
            this.buttonsudoku55.Name = "buttonsudoku55";
            this.buttonsudoku55.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku55.TabIndex = 172;
            // 
            // buttonsudoku56
            // 
            this.buttonsudoku56.Location = new System.Drawing.Point(393, 427);
            this.buttonsudoku56.Name = "buttonsudoku56";
            this.buttonsudoku56.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku56.TabIndex = 171;
            // 
            // buttonsudoku57
            // 
            this.buttonsudoku57.Location = new System.Drawing.Point(351, 427);
            this.buttonsudoku57.Name = "buttonsudoku57";
            this.buttonsudoku57.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku57.TabIndex = 170;
            // 
            // buttonsudoku58
            // 
            this.buttonsudoku58.Location = new System.Drawing.Point(435, 379);
            this.buttonsudoku58.Name = "buttonsudoku58";
            this.buttonsudoku58.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku58.TabIndex = 169;
            // 
            // buttonsudoku59
            // 
            this.buttonsudoku59.Location = new System.Drawing.Point(393, 379);
            this.buttonsudoku59.Name = "buttonsudoku59";
            this.buttonsudoku59.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku59.TabIndex = 168;
            // 
            // buttonsudoku60
            // 
            this.buttonsudoku60.Location = new System.Drawing.Point(351, 379);
            this.buttonsudoku60.Name = "buttonsudoku60";
            this.buttonsudoku60.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku60.TabIndex = 167;
            // 
            // buttonsudoku61
            // 
            this.buttonsudoku61.Location = new System.Drawing.Point(435, 331);
            this.buttonsudoku61.Name = "buttonsudoku61";
            this.buttonsudoku61.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku61.TabIndex = 166;
            // 
            // buttonsudoku62
            // 
            this.buttonsudoku62.Location = new System.Drawing.Point(393, 331);
            this.buttonsudoku62.Name = "buttonsudoku62";
            this.buttonsudoku62.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku62.TabIndex = 165;
            // 
            // buttonsudoku63
            // 
            this.buttonsudoku63.Location = new System.Drawing.Point(351, 331);
            this.buttonsudoku63.Name = "buttonsudoku63";
            this.buttonsudoku63.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku63.TabIndex = 164;
            // 
            // buttonsudoku64
            // 
            this.buttonsudoku64.Location = new System.Drawing.Point(299, 427);
            this.buttonsudoku64.Name = "buttonsudoku64";
            this.buttonsudoku64.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku64.TabIndex = 163;
            // 
            // buttonsudoku65
            // 
            this.buttonsudoku65.Location = new System.Drawing.Point(257, 427);
            this.buttonsudoku65.Name = "buttonsudoku65";
            this.buttonsudoku65.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku65.TabIndex = 162;
            // 
            // buttonsudoku66
            // 
            this.buttonsudoku66.Location = new System.Drawing.Point(215, 427);
            this.buttonsudoku66.Name = "buttonsudoku66";
            this.buttonsudoku66.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku66.TabIndex = 161;
            // 
            // buttonsudoku67
            // 
            this.buttonsudoku67.Location = new System.Drawing.Point(299, 379);
            this.buttonsudoku67.Name = "buttonsudoku67";
            this.buttonsudoku67.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku67.TabIndex = 160;
            // 
            // buttonsudoku68
            // 
            this.buttonsudoku68.Location = new System.Drawing.Point(257, 379);
            this.buttonsudoku68.Name = "buttonsudoku68";
            this.buttonsudoku68.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku68.TabIndex = 159;
            // 
            // buttonsudoku69
            // 
            this.buttonsudoku69.Location = new System.Drawing.Point(215, 379);
            this.buttonsudoku69.Name = "buttonsudoku69";
            this.buttonsudoku69.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku69.TabIndex = 158;
            // 
            // buttonsudoku70
            // 
            this.buttonsudoku70.Location = new System.Drawing.Point(299, 331);
            this.buttonsudoku70.Name = "buttonsudoku70";
            this.buttonsudoku70.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku70.TabIndex = 157;
            // 
            // buttonsudoku71
            // 
            this.buttonsudoku71.Location = new System.Drawing.Point(257, 331);
            this.buttonsudoku71.Name = "buttonsudoku71";
            this.buttonsudoku71.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku71.TabIndex = 156;
            // 
            // buttonsudoku72
            // 
            this.buttonsudoku72.Location = new System.Drawing.Point(215, 331);
            this.buttonsudoku72.Name = "buttonsudoku72";
            this.buttonsudoku72.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku72.TabIndex = 155;
            // 
            // buttonsudoku73
            // 
            this.buttonsudoku73.Location = new System.Drawing.Point(163, 427);
            this.buttonsudoku73.Name = "buttonsudoku73";
            this.buttonsudoku73.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku73.TabIndex = 154;
            // 
            // buttonsudoku74
            // 
            this.buttonsudoku74.Location = new System.Drawing.Point(121, 427);
            this.buttonsudoku74.Name = "buttonsudoku74";
            this.buttonsudoku74.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku74.TabIndex = 153;
            // 
            // buttonsudoku75
            // 
            this.buttonsudoku75.Location = new System.Drawing.Point(79, 427);
            this.buttonsudoku75.Name = "buttonsudoku75";
            this.buttonsudoku75.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku75.TabIndex = 152;
            // 
            // buttonsudoku76
            // 
            this.buttonsudoku76.Location = new System.Drawing.Point(163, 379);
            this.buttonsudoku76.Name = "buttonsudoku76";
            this.buttonsudoku76.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku76.TabIndex = 151;
            // 
            // buttonsudoku77
            // 
            this.buttonsudoku77.Location = new System.Drawing.Point(121, 379);
            this.buttonsudoku77.Name = "buttonsudoku77";
            this.buttonsudoku77.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku77.TabIndex = 150;
            // 
            // buttonsudoku78
            // 
            this.buttonsudoku78.Location = new System.Drawing.Point(79, 379);
            this.buttonsudoku78.Name = "buttonsudoku78";
            this.buttonsudoku78.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku78.TabIndex = 149;
            // 
            // buttonsudoku79
            // 
            this.buttonsudoku79.Location = new System.Drawing.Point(163, 331);
            this.buttonsudoku79.Name = "buttonsudoku79";
            this.buttonsudoku79.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku79.TabIndex = 148;
            // 
            // buttonsudoku80
            // 
            this.buttonsudoku80.Location = new System.Drawing.Point(121, 331);
            this.buttonsudoku80.Name = "buttonsudoku80";
            this.buttonsudoku80.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku80.TabIndex = 147;
            // 
            // buttonsudoku81
            // 
            this.buttonsudoku81.Location = new System.Drawing.Point(79, 331);
            this.buttonsudoku81.Name = "buttonsudoku81";
            this.buttonsudoku81.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku81.TabIndex = 146;
            // 
            // buttonsudoku28
            // 
            this.buttonsudoku28.Location = new System.Drawing.Point(435, 279);
            this.buttonsudoku28.Name = "buttonsudoku28";
            this.buttonsudoku28.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku28.TabIndex = 145;
            // 
            // buttonsudoku29
            // 
            this.buttonsudoku29.Location = new System.Drawing.Point(393, 279);
            this.buttonsudoku29.Name = "buttonsudoku29";
            this.buttonsudoku29.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku29.TabIndex = 144;
            // 
            // buttonsudoku30
            // 
            this.buttonsudoku30.Location = new System.Drawing.Point(351, 279);
            this.buttonsudoku30.Name = "buttonsudoku30";
            this.buttonsudoku30.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku30.TabIndex = 143;
            // 
            // buttonsudoku31
            // 
            this.buttonsudoku31.Location = new System.Drawing.Point(435, 231);
            this.buttonsudoku31.Name = "buttonsudoku31";
            this.buttonsudoku31.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku31.TabIndex = 142;
            // 
            // buttonsudoku32
            // 
            this.buttonsudoku32.Location = new System.Drawing.Point(393, 231);
            this.buttonsudoku32.Name = "buttonsudoku32";
            this.buttonsudoku32.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku32.TabIndex = 141;
            // 
            // buttonsudoku33
            // 
            this.buttonsudoku33.Location = new System.Drawing.Point(351, 231);
            this.buttonsudoku33.Name = "buttonsudoku33";
            this.buttonsudoku33.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku33.TabIndex = 140;
            // 
            // buttonsudoku34
            // 
            this.buttonsudoku34.Location = new System.Drawing.Point(435, 183);
            this.buttonsudoku34.Name = "buttonsudoku34";
            this.buttonsudoku34.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku34.TabIndex = 139;
            // 
            // buttonsudoku35
            // 
            this.buttonsudoku35.Location = new System.Drawing.Point(393, 183);
            this.buttonsudoku35.Name = "buttonsudoku35";
            this.buttonsudoku35.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku35.TabIndex = 138;
            // 
            // buttonsudoku36
            // 
            this.buttonsudoku36.Location = new System.Drawing.Point(351, 183);
            this.buttonsudoku36.Name = "buttonsudoku36";
            this.buttonsudoku36.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku36.TabIndex = 137;
            // 
            // buttonsudoku37
            // 
            this.buttonsudoku37.Location = new System.Drawing.Point(299, 279);
            this.buttonsudoku37.Name = "buttonsudoku37";
            this.buttonsudoku37.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku37.TabIndex = 136;
            // 
            // buttonsudoku38
            // 
            this.buttonsudoku38.Location = new System.Drawing.Point(257, 279);
            this.buttonsudoku38.Name = "buttonsudoku38";
            this.buttonsudoku38.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku38.TabIndex = 135;
            // 
            // buttonsudoku39
            // 
            this.buttonsudoku39.Location = new System.Drawing.Point(215, 279);
            this.buttonsudoku39.Name = "buttonsudoku39";
            this.buttonsudoku39.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku39.TabIndex = 134;
            // 
            // buttonsudoku40
            // 
            this.buttonsudoku40.Location = new System.Drawing.Point(299, 231);
            this.buttonsudoku40.Name = "buttonsudoku40";
            this.buttonsudoku40.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku40.TabIndex = 133;
            // 
            // buttonsudoku41
            // 
            this.buttonsudoku41.Location = new System.Drawing.Point(257, 231);
            this.buttonsudoku41.Name = "buttonsudoku41";
            this.buttonsudoku41.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku41.TabIndex = 132;
            // 
            // buttonsudoku42
            // 
            this.buttonsudoku42.Location = new System.Drawing.Point(215, 231);
            this.buttonsudoku42.Name = "buttonsudoku42";
            this.buttonsudoku42.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku42.TabIndex = 131;
            // 
            // buttonsudoku43
            // 
            this.buttonsudoku43.Location = new System.Drawing.Point(299, 183);
            this.buttonsudoku43.Name = "buttonsudoku43";
            this.buttonsudoku43.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku43.TabIndex = 130;
            // 
            // buttonsudoku44
            // 
            this.buttonsudoku44.Location = new System.Drawing.Point(257, 183);
            this.buttonsudoku44.Name = "buttonsudoku44";
            this.buttonsudoku44.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku44.TabIndex = 129;
            // 
            // buttonsudoku45
            // 
            this.buttonsudoku45.Location = new System.Drawing.Point(215, 183);
            this.buttonsudoku45.Name = "buttonsudoku45";
            this.buttonsudoku45.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku45.TabIndex = 128;
            // 
            // buttonsudoku46
            // 
            this.buttonsudoku46.Location = new System.Drawing.Point(163, 279);
            this.buttonsudoku46.Name = "buttonsudoku46";
            this.buttonsudoku46.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku46.TabIndex = 127;
            // 
            // buttonsudoku47
            // 
            this.buttonsudoku47.Location = new System.Drawing.Point(121, 279);
            this.buttonsudoku47.Name = "buttonsudoku47";
            this.buttonsudoku47.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku47.TabIndex = 126;
            // 
            // buttonsudoku48
            // 
            this.buttonsudoku48.Location = new System.Drawing.Point(79, 279);
            this.buttonsudoku48.Name = "buttonsudoku48";
            this.buttonsudoku48.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku48.TabIndex = 125;
            // 
            // buttonsudoku49
            // 
            this.buttonsudoku49.Location = new System.Drawing.Point(163, 231);
            this.buttonsudoku49.Name = "buttonsudoku49";
            this.buttonsudoku49.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku49.TabIndex = 124;
            // 
            // buttonsudoku50
            // 
            this.buttonsudoku50.Location = new System.Drawing.Point(121, 231);
            this.buttonsudoku50.Name = "buttonsudoku50";
            this.buttonsudoku50.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku50.TabIndex = 123;
            // 
            // buttonsudoku51
            // 
            this.buttonsudoku51.Location = new System.Drawing.Point(79, 231);
            this.buttonsudoku51.Name = "buttonsudoku51";
            this.buttonsudoku51.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku51.TabIndex = 122;
            // 
            // buttonsudoku52
            // 
            this.buttonsudoku52.Location = new System.Drawing.Point(163, 183);
            this.buttonsudoku52.Name = "buttonsudoku52";
            this.buttonsudoku52.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku52.TabIndex = 121;
            // 
            // buttonsudoku53
            // 
            this.buttonsudoku53.Location = new System.Drawing.Point(121, 183);
            this.buttonsudoku53.Name = "buttonsudoku53";
            this.buttonsudoku53.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku53.TabIndex = 120;
            // 
            // buttonsudoku54
            // 
            this.buttonsudoku54.Location = new System.Drawing.Point(79, 183);
            this.buttonsudoku54.Name = "buttonsudoku54";
            this.buttonsudoku54.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku54.TabIndex = 119;
            // 
            // buttonsudoku19
            // 
            this.buttonsudoku19.Location = new System.Drawing.Point(435, 124);
            this.buttonsudoku19.Name = "buttonsudoku19";
            this.buttonsudoku19.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku19.TabIndex = 118;
            // 
            // buttonsudoku20
            // 
            this.buttonsudoku20.Location = new System.Drawing.Point(393, 124);
            this.buttonsudoku20.Name = "buttonsudoku20";
            this.buttonsudoku20.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku20.TabIndex = 117;
            // 
            // buttonsudoku21
            // 
            this.buttonsudoku21.Location = new System.Drawing.Point(351, 124);
            this.buttonsudoku21.Name = "buttonsudoku21";
            this.buttonsudoku21.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku21.TabIndex = 116;
            // 
            // buttonsudoku22
            // 
            this.buttonsudoku22.Location = new System.Drawing.Point(435, 76);
            this.buttonsudoku22.Name = "buttonsudoku22";
            this.buttonsudoku22.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku22.TabIndex = 115;
            // 
            // buttonsudoku23
            // 
            this.buttonsudoku23.Location = new System.Drawing.Point(393, 76);
            this.buttonsudoku23.Name = "buttonsudoku23";
            this.buttonsudoku23.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku23.TabIndex = 114;
            // 
            // buttonsudoku24
            // 
            this.buttonsudoku24.Location = new System.Drawing.Point(351, 76);
            this.buttonsudoku24.Name = "buttonsudoku24";
            this.buttonsudoku24.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku24.TabIndex = 113;
            // 
            // buttonsudoku25
            // 
            this.buttonsudoku25.Location = new System.Drawing.Point(435, 28);
            this.buttonsudoku25.Name = "buttonsudoku25";
            this.buttonsudoku25.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku25.TabIndex = 112;
            // 
            // buttonsudoku26
            // 
            this.buttonsudoku26.Location = new System.Drawing.Point(393, 28);
            this.buttonsudoku26.Name = "buttonsudoku26";
            this.buttonsudoku26.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku26.TabIndex = 111;
            // 
            // buttonsudoku27
            // 
            this.buttonsudoku27.Location = new System.Drawing.Point(351, 28);
            this.buttonsudoku27.Name = "buttonsudoku27";
            this.buttonsudoku27.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku27.TabIndex = 110;
            // 
            // buttonsudoku10
            // 
            this.buttonsudoku10.Location = new System.Drawing.Point(299, 124);
            this.buttonsudoku10.Name = "buttonsudoku10";
            this.buttonsudoku10.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku10.TabIndex = 109;
            // 
            // buttonsudoku11
            // 
            this.buttonsudoku11.Location = new System.Drawing.Point(257, 124);
            this.buttonsudoku11.Name = "buttonsudoku11";
            this.buttonsudoku11.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku11.TabIndex = 108;
            // 
            // buttonsudoku12
            // 
            this.buttonsudoku12.Location = new System.Drawing.Point(215, 124);
            this.buttonsudoku12.Name = "buttonsudoku12";
            this.buttonsudoku12.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku12.TabIndex = 107;
            // 
            // buttonsudoku13
            // 
            this.buttonsudoku13.Location = new System.Drawing.Point(299, 76);
            this.buttonsudoku13.Name = "buttonsudoku13";
            this.buttonsudoku13.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku13.TabIndex = 106;
            // 
            // buttonsudoku14
            // 
            this.buttonsudoku14.Location = new System.Drawing.Point(257, 76);
            this.buttonsudoku14.Name = "buttonsudoku14";
            this.buttonsudoku14.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku14.TabIndex = 105;
            // 
            // buttonsudoku15
            // 
            this.buttonsudoku15.Location = new System.Drawing.Point(215, 76);
            this.buttonsudoku15.Name = "buttonsudoku15";
            this.buttonsudoku15.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku15.TabIndex = 104;
            // 
            // buttonsudoku16
            // 
            this.buttonsudoku16.Location = new System.Drawing.Point(299, 28);
            this.buttonsudoku16.Name = "buttonsudoku16";
            this.buttonsudoku16.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku16.TabIndex = 103;
            // 
            // buttonsudoku17
            // 
            this.buttonsudoku17.Location = new System.Drawing.Point(257, 28);
            this.buttonsudoku17.Name = "buttonsudoku17";
            this.buttonsudoku17.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku17.TabIndex = 102;
            // 
            // buttonsudoku18
            // 
            this.buttonsudoku18.Location = new System.Drawing.Point(215, 28);
            this.buttonsudoku18.Name = "buttonsudoku18";
            this.buttonsudoku18.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku18.TabIndex = 101;
            // 
            // buttonsudoku7
            // 
            this.buttonsudoku7.Location = new System.Drawing.Point(163, 124);
            this.buttonsudoku7.Name = "buttonsudoku7";
            this.buttonsudoku7.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku7.TabIndex = 100;
            // 
            // buttonsudoku8
            // 
            this.buttonsudoku8.Location = new System.Drawing.Point(121, 124);
            this.buttonsudoku8.Name = "buttonsudoku8";
            this.buttonsudoku8.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku8.TabIndex = 99;
            // 
            // buttonsudoku9
            // 
            this.buttonsudoku9.Location = new System.Drawing.Point(79, 124);
            this.buttonsudoku9.Name = "buttonsudoku9";
            this.buttonsudoku9.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku9.TabIndex = 98;
            // 
            // buttonsudoku4
            // 
            this.buttonsudoku4.Location = new System.Drawing.Point(163, 76);
            this.buttonsudoku4.Name = "buttonsudoku4";
            this.buttonsudoku4.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku4.TabIndex = 97;
            // 
            // buttonsudoku5
            // 
            this.buttonsudoku5.Location = new System.Drawing.Point(121, 76);
            this.buttonsudoku5.Name = "buttonsudoku5";
            this.buttonsudoku5.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku5.TabIndex = 96;
            // 
            // buttonsudoku6
            // 
            this.buttonsudoku6.Location = new System.Drawing.Point(79, 76);
            this.buttonsudoku6.Name = "buttonsudoku6";
            this.buttonsudoku6.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku6.TabIndex = 95;
            // 
            // buttonsudoku3
            // 
            this.buttonsudoku3.Location = new System.Drawing.Point(163, 28);
            this.buttonsudoku3.Name = "buttonsudoku3";
            this.buttonsudoku3.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku3.TabIndex = 94;
            // 
            // buttonsudoku2
            // 
            this.buttonsudoku2.Location = new System.Drawing.Point(121, 28);
            this.buttonsudoku2.Name = "buttonsudoku2";
            this.buttonsudoku2.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku2.TabIndex = 93;
            // 
            // buttonsudoku1
            // 
            this.buttonsudoku1.Location = new System.Drawing.Point(79, 28);
            this.buttonsudoku1.Name = "buttonsudoku1";
            this.buttonsudoku1.Size = new System.Drawing.Size(36, 42);
            this.buttonsudoku1.TabIndex = 92;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 112);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 23);
            this.button1.TabIndex = 173;
            this.button1.Text = "SET";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(482, 34);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(21, 20);
            this.button2.TabIndex = 174;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(657, 518);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonsudoku55);
            this.Controls.Add(this.buttonsudoku56);
            this.Controls.Add(this.buttonsudoku57);
            this.Controls.Add(this.buttonsudoku58);
            this.Controls.Add(this.buttonsudoku59);
            this.Controls.Add(this.buttonsudoku60);
            this.Controls.Add(this.buttonsudoku61);
            this.Controls.Add(this.buttonsudoku62);
            this.Controls.Add(this.buttonsudoku63);
            this.Controls.Add(this.buttonsudoku64);
            this.Controls.Add(this.buttonsudoku65);
            this.Controls.Add(this.buttonsudoku66);
            this.Controls.Add(this.buttonsudoku67);
            this.Controls.Add(this.buttonsudoku68);
            this.Controls.Add(this.buttonsudoku69);
            this.Controls.Add(this.buttonsudoku70);
            this.Controls.Add(this.buttonsudoku71);
            this.Controls.Add(this.buttonsudoku72);
            this.Controls.Add(this.buttonsudoku73);
            this.Controls.Add(this.buttonsudoku74);
            this.Controls.Add(this.buttonsudoku75);
            this.Controls.Add(this.buttonsudoku76);
            this.Controls.Add(this.buttonsudoku77);
            this.Controls.Add(this.buttonsudoku78);
            this.Controls.Add(this.buttonsudoku79);
            this.Controls.Add(this.buttonsudoku80);
            this.Controls.Add(this.buttonsudoku81);
            this.Controls.Add(this.buttonsudoku28);
            this.Controls.Add(this.buttonsudoku29);
            this.Controls.Add(this.buttonsudoku30);
            this.Controls.Add(this.buttonsudoku31);
            this.Controls.Add(this.buttonsudoku32);
            this.Controls.Add(this.buttonsudoku33);
            this.Controls.Add(this.buttonsudoku34);
            this.Controls.Add(this.buttonsudoku35);
            this.Controls.Add(this.buttonsudoku36);
            this.Controls.Add(this.buttonsudoku37);
            this.Controls.Add(this.buttonsudoku38);
            this.Controls.Add(this.buttonsudoku39);
            this.Controls.Add(this.buttonsudoku40);
            this.Controls.Add(this.buttonsudoku41);
            this.Controls.Add(this.buttonsudoku42);
            this.Controls.Add(this.buttonsudoku43);
            this.Controls.Add(this.buttonsudoku44);
            this.Controls.Add(this.buttonsudoku45);
            this.Controls.Add(this.buttonsudoku46);
            this.Controls.Add(this.buttonsudoku47);
            this.Controls.Add(this.buttonsudoku48);
            this.Controls.Add(this.buttonsudoku49);
            this.Controls.Add(this.buttonsudoku50);
            this.Controls.Add(this.buttonsudoku51);
            this.Controls.Add(this.buttonsudoku52);
            this.Controls.Add(this.buttonsudoku53);
            this.Controls.Add(this.buttonsudoku54);
            this.Controls.Add(this.buttonsudoku19);
            this.Controls.Add(this.buttonsudoku20);
            this.Controls.Add(this.buttonsudoku21);
            this.Controls.Add(this.buttonsudoku22);
            this.Controls.Add(this.buttonsudoku23);
            this.Controls.Add(this.buttonsudoku24);
            this.Controls.Add(this.buttonsudoku25);
            this.Controls.Add(this.buttonsudoku26);
            this.Controls.Add(this.buttonsudoku27);
            this.Controls.Add(this.buttonsudoku10);
            this.Controls.Add(this.buttonsudoku11);
            this.Controls.Add(this.buttonsudoku12);
            this.Controls.Add(this.buttonsudoku13);
            this.Controls.Add(this.buttonsudoku14);
            this.Controls.Add(this.buttonsudoku15);
            this.Controls.Add(this.buttonsudoku16);
            this.Controls.Add(this.buttonsudoku17);
            this.Controls.Add(this.buttonsudoku18);
            this.Controls.Add(this.buttonsudoku7);
            this.Controls.Add(this.buttonsudoku8);
            this.Controls.Add(this.buttonsudoku9);
            this.Controls.Add(this.buttonsudoku4);
            this.Controls.Add(this.buttonsudoku5);
            this.Controls.Add(this.buttonsudoku6);
            this.Controls.Add(this.buttonsudoku3);
            this.Controls.Add(this.buttonsudoku2);
            this.Controls.Add(this.buttonsudoku1);
            this.Controls.Add(this.button91);
            this.Controls.Add(this.button88);
            this.Controls.Add(this.button89);
            this.Controls.Add(this.button90);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button87);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button82);
            this.Name = "Form1";
            this.Text = "SUDOKU";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private buttonsudoku buttonsudoku1;
        private buttonsudoku buttonsudoku2;
        private buttonsudoku buttonsudoku3;
        private buttonsudoku buttonsudoku4;
        private buttonsudoku buttonsudoku5;
        private buttonsudoku buttonsudoku6;
        private buttonsudoku buttonsudoku7;
        private buttonsudoku buttonsudoku8;
        private buttonsudoku buttonsudoku9;
        private buttonsudoku buttonsudoku10;
        private buttonsudoku buttonsudoku11;
        private buttonsudoku buttonsudoku12;
        private buttonsudoku buttonsudoku13;
        private buttonsudoku buttonsudoku14;
        private buttonsudoku buttonsudoku15;
        private buttonsudoku buttonsudoku16;
        private buttonsudoku buttonsudoku17;
        private buttonsudoku buttonsudoku18;
        private buttonsudoku buttonsudoku19;
        private buttonsudoku buttonsudoku20;
        private buttonsudoku buttonsudoku21;
        private buttonsudoku buttonsudoku22;
        private buttonsudoku buttonsudoku23;
        private buttonsudoku buttonsudoku24;
        private buttonsudoku buttonsudoku25;
        private buttonsudoku buttonsudoku26;
        private buttonsudoku buttonsudoku27;
        private buttonsudoku buttonsudoku28;
        private buttonsudoku buttonsudoku29;
        private buttonsudoku buttonsudoku30;
        private buttonsudoku buttonsudoku31;
        private buttonsudoku buttonsudoku32;
        private buttonsudoku buttonsudoku33;
        private buttonsudoku buttonsudoku34;
        private buttonsudoku buttonsudoku35;
        private buttonsudoku buttonsudoku36;
        private buttonsudoku buttonsudoku37;
        private buttonsudoku buttonsudoku38;
        private buttonsudoku buttonsudoku39;
        private buttonsudoku buttonsudoku40;
        private buttonsudoku buttonsudoku41;
        private buttonsudoku buttonsudoku42;
        private buttonsudoku buttonsudoku43;
        private buttonsudoku buttonsudoku44;
        private buttonsudoku buttonsudoku45;
        private buttonsudoku buttonsudoku46;
        private buttonsudoku buttonsudoku47;
        private buttonsudoku buttonsudoku48;
        private buttonsudoku buttonsudoku49;
        private buttonsudoku buttonsudoku50;
        private buttonsudoku buttonsudoku51;
        private buttonsudoku buttonsudoku52;
        private buttonsudoku buttonsudoku53;
        private buttonsudoku buttonsudoku54;
        private buttonsudoku buttonsudoku55;
        private buttonsudoku buttonsudoku56;
        private buttonsudoku buttonsudoku57;
        private buttonsudoku buttonsudoku58;
        private buttonsudoku buttonsudoku59;
        private buttonsudoku buttonsudoku60;
        private buttonsudoku buttonsudoku61;
        private buttonsudoku buttonsudoku62;
        private buttonsudoku buttonsudoku63;
        private buttonsudoku buttonsudoku64;
        private buttonsudoku buttonsudoku65;
        private buttonsudoku buttonsudoku66;
        private buttonsudoku buttonsudoku67;
        private buttonsudoku buttonsudoku68;
        private buttonsudoku buttonsudoku69;
        private buttonsudoku buttonsudoku70;
        private buttonsudoku buttonsudoku71;
        private buttonsudoku buttonsudoku72;
        private buttonsudoku buttonsudoku73;
        private buttonsudoku buttonsudoku74;
        private buttonsudoku buttonsudoku75;
        private buttonsudoku buttonsudoku76;
        private buttonsudoku buttonsudoku77;
        private buttonsudoku buttonsudoku78;
        private buttonsudoku buttonsudoku79;
        private buttonsudoku buttonsudoku80;
        private buttonsudoku buttonsudoku81;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

